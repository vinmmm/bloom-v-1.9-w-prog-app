// Invoke 'strict' JavaScript mode
'use strict';

// Create the 'orders' module
angular.module('orders', []);