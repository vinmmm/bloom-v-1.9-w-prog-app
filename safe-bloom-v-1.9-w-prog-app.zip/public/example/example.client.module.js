// Invoke 'strict' JavaScript mode
'use strict';

// Create the 'example' module
angular.module('example', []);