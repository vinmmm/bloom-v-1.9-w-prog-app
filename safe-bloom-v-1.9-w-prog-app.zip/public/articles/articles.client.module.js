// Invoke 'strict' JavaScript mode
'use strict';

// Create the 'articles' module
angular.module('articles', []);